package com.example.winuser.antipickpocket;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button protec_btn= (Button) findViewById(R.id.protect_btn);
protec_btn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
startActivity(new Intent(getApplicationContext(),PhoneProtected.class));
    }
});

        protec_btn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent motionEvent) {
                switch (motionEvent.getAction()){
                    case MotionEvent.ACTION_UP:
                    {
                        Button view=(Button)v;
                        view.setBackgroundResource(R.drawable.protecc);
                        v.invalidate();
                        break;
                    }

                    case MotionEvent.ACTION_DOWN:
                    {
                        Button view=(Button)v;
                        view.setBackgroundResource(R.drawable.protecc_clicked);
                        v.invalidate();
                        break;
                    }
                }
                return false;
            }
        });
    }
}
