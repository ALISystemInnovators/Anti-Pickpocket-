package com.gscreatives.antipickpocket.owner;

import java.util.Map;

public class WiFi {
	private Map<String, Integer> wifi;

	public Map<String, Integer> getWifi() {
		return wifi;
	}

	public void setWifi(Map<String, Integer> wifi) {
		this.wifi = wifi;
	}
}
