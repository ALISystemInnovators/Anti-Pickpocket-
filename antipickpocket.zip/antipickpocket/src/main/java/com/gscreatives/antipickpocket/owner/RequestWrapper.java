package com.gscreatives.antipickpocket.owner;

import java.util.List;

public class RequestWrapper {

	List<WiFi> wifi;
	
	public List<WiFi> getWifi() {
		return wifi;
	}
	
	public void setWifi(List<WiFi> wifi) {
		this.wifi = wifi;
	}
}
