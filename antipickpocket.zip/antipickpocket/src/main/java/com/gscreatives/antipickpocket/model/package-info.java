/**
 * The classes in this package represent utilities used by the domain.
 */
package com.gscreatives.antipickpocket.model;

