/*
 * Copyright 2012-2018 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.gscreatives.antipickpocket.owner;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import org.assertj.core.util.Maps;
//import org.springframework.boot.json.JsonParseException;
//import org.springframework.boot.json.JsonParser;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gscreatives.antipickpocket.model.Person;
import com.gscreatives.antipickpocket.model.SensorData;
import com.gscreatives.antipickpocket.vet.Specialty;
import com.gscreatives.antipickpocket.vet.Vet;
import com.gscreatives.antipickpocket.vet.VetRepository;

//import net.minidev.json.JSONObject;

/**
 * @author Juergen Hoeller
 * @author Ken Krebs
 * @author Arjen Poutsma
 * @author Michael Isvy
 */
@Controller
class OwnerController {

	private static final String VIEWS_OWNER_CREATE_OR_UPDATE_FORM = "owners/createOrUpdateOwnerForm";
	private final OwnerRepository owners;
	private final VetRepository wifiTagService;

	private Map<String, Vet> updatedWifiTags;
	private Map<String, Owner> updatedPhones;

	public OwnerController(OwnerRepository clinicService, VetRepository wifiTagService) {
		this.owners = clinicService;
		this.wifiTagService = wifiTagService;

		updatedWifiTags = new HashMap<>();
		updatedPhones = new HashMap<>();
	}

	@InitBinder
	public void setAllowedFields(WebDataBinder dataBinder) {
		dataBinder.setDisallowedFields("id");
	}

	@GetMapping("/owners/new")
	public String initCreationForm(Map<String, Object> model) {
		Owner owner = new Owner();
		model.put("owner", owner);
		return VIEWS_OWNER_CREATE_OR_UPDATE_FORM;
	}

	@PostMapping("/owners/new")
	public String processCreationForm(@Valid Owner owner, BindingResult result) {
		if (result.hasErrors()) {
			return VIEWS_OWNER_CREATE_OR_UPDATE_FORM;
		} else {
			this.owners.save(owner);
			return "redirect:/owners/" + owner.getId();
		}
	}

	@GetMapping("/owners/find")
	public String initFindForm(Map<String, Object> model) {
		model.put("owner", new Owner());
		return "owners/findOwners";
	}

	@GetMapping("/owners")
	public String processFindForm(Owner owner, BindingResult result, Map<String, Object> model) {

		// allow parameterless GET request for /owners to return all records
		if (owner.getMacAddress() == null) {
			owner.setMacAddress(""); // empty string signifies broadest possible search
		}

		// find owners by last name
		Owner results = this.owners.findByLastName(owner.getMacAddress());
		// if (results.isEmpty()) {
		// no owners found
		result.rejectValue("password", "notFound", "not found");
		return "owners/findOwners";
		// }
		// else if (results.size() == 1) {
		// // 1 owner found
		// owner = results.iterator().next();
		// return "redirect:/owners/" + owner.getId();
		// } else {
		// // multiple owners found
		// model.put("selections", results);
		// return "owners/ownersList";
		// }
	}

	@GetMapping("/owners/{ownerId}/edit")
	public String initUpdateOwnerForm(@PathVariable("ownerId") int ownerId, Model model) {
		Owner owner = this.owners.findById(ownerId);
		model.addAttribute(owner);
		return VIEWS_OWNER_CREATE_OR_UPDATE_FORM;
	}

	@PostMapping("/owners/{ownerId}/edit")
	public String processUpdateOwnerForm(@Valid Owner owner, BindingResult result,
			@PathVariable("ownerId") int ownerId) {
		if (result.hasErrors()) {
			return VIEWS_OWNER_CREATE_OR_UPDATE_FORM;
		} else {
			owner.setId(ownerId);
			this.owners.save(owner);
			return "redirect:/owners/{ownerId}";
		}
	}

	/**
	 * Custom handler for displaying an owner.
	 *
	 * @param ownerId
	 *            the ID of the owner to display
	 * @return a ModelMap with the model attributes for the view
	 */
	@GetMapping("/owners/{ownerId}")
	public ModelAndView showOwner(@PathVariable("ownerId") int ownerId) {
		ModelAndView mav = new ModelAndView("owners/ownerDetails");
		mav.addObject(this.owners.findById(ownerId));
		return mav;
	}

	@RequestMapping(value = "/ownersupdate", method = RequestMethod.POST)
	public ResponseEntity<RequestWrapper> updateWithMultipleObjects(@RequestParam Map<String, String> body) {

		if (!body.toString().contains("b8:27:eb:95:63:ee") && !body.toString().contains("b0:a2:e7:7b:3c:31")) {
			return null;
		}

		boolean isWifiTag = false;

		Map<String, Object> map = new HashMap<String, Object>();

		String stringOfBody = body.toString().replaceAll("'", "\"");
		stringOfBody = stringOfBody.replaceAll("=", "\"");
		stringOfBody = stringOfBody.replace("\"}", "}");

		System.out.println("stringOfBody::: " + stringOfBody);

		SensorData sensorData = null;
		try {
			sensorData = new ObjectMapper().readValue(stringOfBody, SensorData.class);
		} catch (com.fasterxml.jackson.core.JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("devicexxx1::: " + sensorData.getDevice());
		System.out.println("devicexxx2::: " + body.containsKey("device"));
		System.out.println("devicexxx3::: " + body.containsKey("[device]"));

		// Set<String> keys = body.keySet();
		// Iterator<String> iter = keys.iterator();
		// while(iter.hasNext()) {
		// System.out.println("key::: " + iter.next());
		// }

		Vet wifiTag = wifiTagService.findByMacAddress(sensorData.getDevice());

		System.out.println("wifiTag:: " + wifiTag + ", bodyxoxo:: " + body);

		Person currentDevice = new Person();
		if (wifiTag != null) {
			isWifiTag = true;

			System.out.println("isWifiTag:: " + isWifiTag);

			currentDevice = saveWifiTagInDBase(sensorData);
		} else {
			// save as Phone
			System.out.println("IS NOT WIFI TAG");
			currentDevice = savePhoneInDBase(sensorData);
		}

		System.out.println("device:: [updateWithMultipleObjects] " + currentDevice);

		Person partnerDeviceOrWifiTag = getPartnerDevice(currentDevice, isWifiTag);

		// boolean isWifiTag, Person currentDevice, String partnerMacAddress
		checkIfPartnerHasAlreadyBeenUpdated(isWifiTag, currentDevice, partnerDeviceOrWifiTag.getMacAddress());

		System.out.println("partnerDeviceOrWifiTag(updateWithMultipleObjects)::" + partnerDeviceOrWifiTag);

		System.out.println("wifitag(updateWithMultipleObjects):: " + sensorData.toString());

		System.out.println("before testing if location is not null[device]:: " + currentDevice);
		System.out
				.println("before testing if location is not null[partnerDeviceOrWifiTag]:: " + partnerDeviceOrWifiTag);

		if (currentDevice.getPassword() != null && partnerDeviceOrWifiTag.getPassword() != null) {
			System.out.println("device.getPassword() != null && partnerDeviceOrWifiTag.getPassword() != null");
			if (!currentDevice.getPassword().equalsIgnoreCase(partnerDeviceOrWifiTag.getPassword())) { // they are not
																										// in the
				// same location
				System.out.println("!device.getPassword().equalsIgnoreCase(partnerDeviceOrWifiTag.getPassword())"
						+ " [device->Location]:: " + currentDevice.getPassword()
						+ ", [partnerDeviceOrWifiTag->Location]:: " + partnerDeviceOrWifiTag.getPassword());

				// determine which is the device

				Person phoneDevice = new Person();
				if (isWifiTag) {
					phoneDevice = getPartnerDevice(currentDevice, true);
				} else {
					phoneDevice = currentDevice;
				}

				System.out.println("phoneDevice:: " + phoneDevice);

				sendAlarm(phoneDevice);
			}
		}

		System.out.println("return null");

		return null;

	}

	private boolean checkIfPartnerHasAlreadyBeenUpdated(boolean isWifiTag, Person currentDevice,
			String partnerMacAddress) {
		if (isWifiTag) {
			if (updatedPhones.get(partnerMacAddress) == null) {
				System.out.println("phone has not yet been updated");
				updatedWifiTags.put(currentDevice.getMacAddress(), (Vet) currentDevice);
				return false;
			} else {
				System.out.println("phone has already been updated");
				updatedPhones.remove(partnerMacAddress);
				return true;
			}
		} else if (updatedWifiTags.get(partnerMacAddress) == null) {
			System.out.println("wifitag has not yet been updated");
			updatedPhones.put(currentDevice.getMacAddress(), (Owner) currentDevice);
			return false;
		} else {
			System.out.println("wifitag has already been updated");
			updatedWifiTags.remove(partnerMacAddress);
			return true;
		}
	}

	private void sendAlarm(Person phoneDevice) {
		System.out.println("Phone " + phoneDevice.getMacAddress() + " might be stolen and is currently located at "
				+ phoneDevice.getPassword());
	}

	private Person saveWifiTagInDBase(SensorData body) {
		Vet device = getWiFiTagInDBase(body.getDevice());

		System.out.println("device [saveWifiTagInDBase]1:: " + device);

		if (device != null) {
			if (body.getLocation() != null) {
				device.setPassword(body.getLocation());
			}
		} else {
			device = new Vet();
			device.setMacAddress(body.getDevice());
			if (body.getLocation() != null) {
				device.setPassword(body.getLocation());
			}

			device = getWiFiTagInDBase(body.getDevice()); // so that we have the id
		}

		System.out.println("device [saveWifiTagInDBase]2:: " + device);

		// TODO save in DBase
		wifiTagService.save(device);
		return device;
	}

	private Person savePhoneInDBase(SensorData body) {
		Person device = getDeviceInDBase(body);
		System.out.println("device [savePhoneInDBase]1:: " + device);

		if (device != null) {
			if (body.getLocation() != null) {
				device.setPassword(body.getLocation());
			}
		} else {
			device = new Vet();
			device.setMacAddress(body.getDevice());
			if (body.getLocation() != null) {
				device.setPassword(body.getLocation());
			}

			device = getDeviceInDBase(body); // so that we have the id
		}

		System.out.println("device [savePhoneInDBase]2:: " + device + "body:: " + body.toString());

		// TODO save in DBase
		boolean isForUpdate = false;
		Owner owner = new Owner();
		if (device.getId() > 0) {
			System.out.println("device.getId() > 0:: " + device);
			owner.setId(device.getId());
			isForUpdate = true;
		}
		owner.setMacAddress(device.getMacAddress());
		owner.setPassword(device.getPassword());

		// owners.save(owner);
		if (isForUpdate) {
			System.out.println("owner is for update:: " + device);
			owners.setPhoneInfoById(device.getMacAddress(), device.getPassword(), device.getId());
			
			Owner checkUpdatedPhone = owners.findByLastName(device.getMacAddress());
			System.out.println("checkUpdatedPhone:: " + checkUpdatedPhone);
		} else {
			System.out.println("owners.save(owner):: " + owner);
			owners.save(owner);
		}

		System.out.println("owner [savePhoneInDBase]:: " + owner);

		return device;
	}

	private Vet getWiFiTagInDBase(String deviceMacAddress) {
		// TODO get in dbase
		Vet wifiTag = wifiTagService.findByMacAddress(deviceMacAddress);

		System.out.println("wifiTag [getWiFiTagInDBase]:: " + wifiTag);

		return wifiTag;
	}

	private Person getDeviceInDBase(SensorData body) {
		// TODO get in dbase

		System.out.println("device [getDeviceInDBase]1:: " + body + ", " + body.getDevice());

		Person device = owners.findByLastName(body.getDevice());
		//// device.setId(1);
		// device.setMacAddress(body.get("device"));
		// device.setPassword("Pond1");

		System.out.println("device [getDeviceInDBase]2:: " + device);

		return device;
	}

	private Person getPartnerDevice(Person currentDevice, boolean isWifiTag) {
		// TODO get partner device in DBase
		// String partnerMacAddress = "b0:a2:e7:7b:3c:31"; // getInDBase()

		if (isWifiTag) {
			Specialty phone = wifiTagService.findDevicePartnerOfThisWifiTagId(currentDevice.getId());
			// return wifiTagService.findWifiTagByMacAddress(macAddress)

			System.out.println("phone (isWifiTag true) [getPartnerDevice]:: " + phone);

			Owner owner = owners.findByLastName(phone.getName());

			System.out.println(
					"owner (isWifiTag true) [getPartnerDevice]:: " + owner + ", :: Location:: " + owner.getPassword());
			return owner;
		} else if (currentDevice != null) {
			// currentDevice is phone
			Specialty wifiTagIdInfo = wifiTagService.findByMacAddressOfPhone(currentDevice.getMacAddress());

			Vet wifiTag = wifiTagService.findWifiTagById(wifiTagIdInfo.getId());

			System.out.println("wifiTag (isWifiTag false) [getPartnerDevice]:: " + wifiTag + ", :: Location:: "
					+ wifiTag.getPassword());
			return wifiTag;
		} else {
			return null;
		}
		// TODO getDeviceInDBase()
		// Person partner = new Person();
		// partner.setMacAddress("b0:a2:e7:7b:3c:31");
		// partner.setPassword("Pond3");
	}
}
